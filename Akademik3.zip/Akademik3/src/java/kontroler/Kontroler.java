/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontroler;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import javax.faces.bean.SessionScoped;
import logika.DBkontroler.PersonKontroler;
import logika.DBkontroler.RoomKontroler;

/**
 *
 * @author marekszymanski
 */
@ManagedBean
@SessionScoped
public class Kontroler {
    @ManagedProperty(value="#{personkontroler}")
    PersonKontroler personKontroler;
    
    @ManagedProperty(value="#{roomkontroler}")
    RoomKontroler roomKontroler;
    
    public String logIn()
    {
        if(personKontroler.logIn())
        {
            System.out.println("Logowanie trwa dla "+personKontroler.getPerson().getStatus());
            return droga(personKontroler.getPerson().getStatus());
        }   
        else
            return "home";
    }
    
    public String registration()
    {
        if(personKontroler.createNew(roomKontroler.manager.allRooms().size()))
            return "home";
        else
            return "home";
    }
    
    private String droga(String kto)
    {
        if(kto.equals("Administrator"))
        {
            System.out.println("Administrator");
            return "adminstrator";
        }   
        if(kto.equals("Mieszkaniec"))
            return "home";
        if(kto.equals("Portier"))
            return "portier";
        return "home";
    }

    public void setPersonKontroler(PersonKontroler personKontroler) {
        this.personKontroler = personKontroler;
    }

    public void setRoomKontroler(RoomKontroler roomKontroler) {
        this.roomKontroler = roomKontroler;
    }
    
    
}
