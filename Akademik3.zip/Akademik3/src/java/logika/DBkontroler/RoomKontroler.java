/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika.DBkontroler;

import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import logika.bean.RoomBean;
import logika.entity.Room;

/**
 *
 * @author marekszymanski
 */
@ManagedBean(name = "roomkontroler")
@SessionScoped
public class RoomKontroler implements Serializable{
    private Room room;
    @EJB
    public RoomBean manager;

    public RoomKontroler() {
        room = new Room();
    }
    
    public boolean createNewRoom()
    {
        if(manager.findByNumber(room.getNumber()).isEmpty())
        {
            manager.createRoom(room);
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void editRoom()
    {
        Room temp = manager.findByNumber(room.getNumber()).get(0);
        if(temp == room)
        {
            manager.update(room);
        }
        else
        {
            System.out.println("Nie da się zaktualizować pokoju");
        }
    }
}
